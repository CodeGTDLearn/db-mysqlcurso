create
    definer = root@`%` function fn_irpf(par_salario decimal(10, 2)) returns decimal(10, 2)
begin
    declare vImposto DEC(10, 2);

    set vImposto = CASE
                       WHEN par_salario <= 1000
                           THEN 0

                       WHEN par_salario >= 1000.01 AND par_salario <= 3000
                           THEN (par_salario * 0.15)

                       WHEN par_salario >= 3000.01 AND par_salario <= 4000
                           THEN (par_salario * 0.25)

                       WHEN par_salario >= 4000.01
                           THEN (par_salario * 0.35)
        end;

    RETURN vImposto;

END;

