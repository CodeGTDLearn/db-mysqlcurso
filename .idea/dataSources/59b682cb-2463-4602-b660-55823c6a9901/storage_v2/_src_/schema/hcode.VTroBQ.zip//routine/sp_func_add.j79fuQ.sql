create
    definer = root@`%` procedure sp_func_add(IN param_Nome varchar(100), IN param_Adm date,
                                             IN param_Salario decimal(10, 2))
begin
    declare varNewIdPessoa INT;

    start transaction;

    IF not exists(select pessoasId from pessoas where pessoasNome = param_Nome) THEN
        insert into pessoas values (null, param_Nome, param_Adm);
        set varNewIdPessoa = last_insert_id();
    ELSE
        select 'Pessoa ja cadastrada! Tente novamente';
        rollback;
    END IF;

    IF NOT exists(select pessoasId from func where pessoasId = varNewIdPessoa) THEN
        insert into func values (null, varNewIdPessoa, param_Salario, param_Adm);
    ELSE
        select 'Funcionario ja cadastrado! Tente novamente';
        rollback;
    END IF;

    commit;

    select 'Funcionario cadastrado com sucesso' as Resultado_Final;
end;

